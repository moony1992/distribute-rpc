package com.gupaoedu.example.rcp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 咕泡学院，只为更好的你
 * 咕泡学院-Mic: 2227324689
 * http://www.gupaoedu.com
 **/
@SpringBootApplication
public class UserServiceMain {

    public static void main(String[] args) {
        SpringApplication.run(UserServiceMain.class,args);
    }
}
